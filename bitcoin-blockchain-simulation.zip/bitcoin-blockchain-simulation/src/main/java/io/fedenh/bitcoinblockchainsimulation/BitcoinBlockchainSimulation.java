package io.fedenh.bitcoinblockchainsimulation;

import com.google.gson.GsonBuilder;
import io.fedenh.bitcoinblockchainsimulation.entities.Block;

import java.util.ArrayList;
import java.util.Objects;

public class BitcoinBlockchainSimulation {
    public static ArrayList<Block> blockChain = new ArrayList<>();
    public static int difficultyLevel = 10;

    public static void main(String[] args) {
        Block b = new Block("0", "Je suis le bloc de genèse");
        System.out.println("Début du minage");
        if (b.miner(difficultyLevel)) {
            blockChain.add(b);
        }

        b = new Block(blockChain.get(blockChain.size() - 1).hash, "Je suis le second bloc");
        if (b.miner(difficultyLevel)) {
            blockChain.add(b);
        }

        b = new Block(blockChain.get(blockChain.size() - 1).hash, "Je suis le troisième bloc");
        if (b.miner(difficultyLevel)) {
            blockChain.add(b);
        }

        String json = new GsonBuilder().setPrettyPrinting().create().toJson(blockChain);
        System.out.println(json);

        System.out.println("Blockchain validity : " + verifyBlockchain());

    }

    public static boolean verifyBlockchain() {
        Block previous;
        Block current;
        for (int i = 0; i < blockChain.size(); i++) {
            current = blockChain.get(i);
            if (i > 0) {
                previous = blockChain.get(i - 1);
                if (!Objects.equals(previous.hash, current.previousHash)) {
                    return false;
                }
            }
            String calculatedHash = current.calculateHash();
            if (!Objects.equals(calculatedHash, current.hash)) {
                return false;
            }
        }
        return true;
    }
}
